package com.blueapps.glpyhconverter.toglyphx.items;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public abstract class Item {

    public abstract Element getElement(Document doc, String MdC);

}
