package com.blueapps.glpyhconverter.tomdc.items;

public abstract class Item {

    public abstract String getMdC();

}
