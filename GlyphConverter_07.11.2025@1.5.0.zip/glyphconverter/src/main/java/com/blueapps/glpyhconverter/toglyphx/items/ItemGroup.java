package com.blueapps.glpyhconverter.toglyphx.items;


public abstract class ItemGroup extends Item{

}
